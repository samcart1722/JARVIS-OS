"""
Default implementation of the MemoryRetriever contract.
"""

from __future__ import annotations

from app.cognition.memory.contracts import (
    MemoryRepository,
    MemoryRetriever,
)
from app.cognition.memory.domain.entities import (
    MemoryQuery,
    RetrievedMemory,
)


class DefaultRetriever(MemoryRetriever):
    """
    Default implementation of the MemoryRetriever.

    This implementation delegates the retrieval process to the
    configured MemoryRepository. Future implementations may add
    caching, hybrid retrieval, vector search, or query expansion
    before accessing the repository.
    """

    def __init__(
        self,
        repository: MemoryRepository,
    ) -> None:
        self._repository = repository

    async def retrieve(
        self,
        query: MemoryQuery,
    ) -> tuple[RetrievedMemory, ...]:
        """
        Retrieve candidate memories.
        """

        result = await self._repository.search(query)

        return result.memories
