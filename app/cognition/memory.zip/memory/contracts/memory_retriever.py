"""
Contract for retrieving memories.
"""

from __future__ import annotations

from typing import Protocol

from app.cognition.memory.domain.entities import (
    MemoryQuery,
    RetrievedMemory,
)


class MemoryRetriever(Protocol):
    """
    Retrieves candidate memories for a query.
    """

    async def retrieve(
        self,
        query: MemoryQuery,
    ) -> tuple[RetrievedMemory, ...]:
        """
        Retrieve candidate memories.
        """
        ...
